package com.autofact.helloworldapp;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World! welcome to the training session on DevOps, Today is Saturday" );
    }
}
